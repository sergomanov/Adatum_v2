<!DOCTYPE html>
<html>
<head>
<?php	
 //include 'autt.php';

 ?>
<link rel="stylesheet" type="text/css" media="all" href="css/googlefont.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/whhg.css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
*
<link href="css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/responsive.css" rel="stylesheet" type="text/css"/>
<script src="js/jquery-1.8.3.min.js" type="text/javascript"></script> 
</head>
<body class="error-body no-top lazy"  data-original="assets/img/work.jpg"  style="background-image: url('css/work.jpg');   background-size:cover;    background-repeat:repeat;    background-position:top;"> 
<div class="container">
  <div class="row login-container animated fadeInUp">  
        <div class="col-md-7 col-md-offset-2 tiles white no-padding">
		 <div class="p-t-30 p-l-40 p-b-20 xs-p-t-10 xs-p-l-10 xs-p-b-10"> 
          <h2 class="normal">Ошибка 404</h2>
          <p>Такой страницы не существует либо у вас недостаточно прав для просмотра.<br></p>
		     <p><br></p>
		 <a href="index.php">Вернутся</a>
        </div>
		  
      </div>   
  </div>
</div>
</body>
</html>