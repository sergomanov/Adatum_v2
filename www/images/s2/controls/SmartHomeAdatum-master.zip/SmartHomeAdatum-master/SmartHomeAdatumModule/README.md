Smart Home Adatum Project
===============
Arduino scratch for Open platform home automation Adatum+.
