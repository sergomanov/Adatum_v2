SmartHomeAdatum
===============

Adatum+ is a fully featured, open source, MIT licensed, Open platform Home automation.


![Adatum+ logo](http://adatum.ru/home.gif)


## Contact

Please contact Sergomanov Dmitry regarding this project, [sergomanov@mail.ru](mailto:sergomanov@mail.ru?subject=SmartHomeAdatum)  

## Credits

Sergomanov Dmitry, [sergomanov](https://www.facebook.com/sergomanov)  


## License

See the LICENSE file for more info.